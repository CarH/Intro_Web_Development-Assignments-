// Esse CSS contém os eventos mais gerais, associados com várias paginas,
// eventos associados ao menu
$(document).ready(function  () {

	$("#registerbtn").click(function(){
		window.location.href = "registration.html";
	});

});